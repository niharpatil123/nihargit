from datetime import datetime
from common.functions import functions
import schedule

class threeleg():

    def __init__(self, conn, tradeSymbol, positionSize, system, user):

        self.tradeSymbol = tradeSymbol
        self.positionSize = positionSize
        self.system = system
        self.user = user
        self.KitecConn = conn
        print("Start Time: ", datetime.now().hour,":",datetime.now().minute,":",datetime.now().second)
        self.fn = functions(self.KitecConn, self.tradeSymbol, self.positionSize, self.system, self.user)

        self.threeLegConfigDic = self.fn.read_file_json('systems/threeLeg/config_threeLeg.json')
        self.fn.sendTelegram(f'ThreeLeg :: Symbol ::{self.tradeSymbol} and Position Size ::{self.positionSize}')

    def scheduler(self):
        
        self.fn.buyHedge()
        self.fn.sellStraddle()
        self.fn.placeStopLoss('leg1')
        self.fn.exitStraddle()
        self.fn.exitHedge()
        # schedule.every().day.at(self.threeLegConfigDic["time"]['hedge']["starttime"]).do(self.fn.buyHedge)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg1"]["starttime"]).do(self.fn.sellStraddle)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg1"]["sltime"]).do(self.fn.placeStopLoss, leg="leg1")
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg1"]["exittime"]).do(self.fn.exitStraddle)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg2"]["starttime"]).do(self.fn.sellStraddle)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg2"]["sltime"]).do(self.fn.placeStopLoss, leg="leg2")
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg2"]["exittime"]).do(self.fn.exitStraddle)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg3"]["starttime"]).do(self.fn.sellStraddle)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg3"]["sltime"]).do(self.fn.placeStopLoss, leg="leg3")
        # schedule.every().day.at(self.threeLegConfigDic["time"]["leg3"]["exittime"]).do(self.fn.exitStraddle)
        # schedule.every().day.at(self.threeLegConfigDic["time"]["hedge"]["exittime"]).do(self.fn.exitHedge)
        # schedule.every().day.at(self.threeLegConfigDic["time"]['hedge']["starttime"]).do(self.fn.checkStatus)