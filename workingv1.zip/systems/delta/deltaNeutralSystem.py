from datetime import datetime
from common.functions import functions

import schedule

class deltaNeutral():

    def __init__(self, conn, tradeSymbol, positionSize, system, user):


        self.tradeSymbol = tradeSymbol
        self.positionSize = positionSize
        self.system = system
        self.user = user
        self.KiteConn = conn
        print("Start Time: ", datetime.now().hour,":",datetime.now().minute,":",datetime.now().second)
        self.fn = functions(self.KiteConn, self.tradeSymbol, self.positionSize, self.system, self.user)
        
        self.fn.sendTelegram(f'DeltaNeutral :: Symbol ::{self.tradeSymbol} and Position Size ::{self.positionSize}')

        self.deltaConfigDic = self.fn.read_file_json('systems/delta/config_delta.json')

    def scheduler(self):
        
        self.fn.buyHedge()
        self.fn.sellStraddle()
        self.fn.isDeltaMisMatch()
        self.fn.cancelSLOrders()

        #schedule.every().day.at(self.deltaConfigDic["time"]['hedge']["starttime"]).do(self.st.buyHedge)
        #schedule.every().day.at(self.deltaConfigDic["time"]["delta"]["starttime"]).do(self.st.sellStraddle)
        #schedule.every().day.at(self.deltaConfigDic["time"]["delta"]["chkdelta"]).do(self.st.checkDeltaStatus)
        #schedule.every().day.at(self.deltaConfigDic["time"]["hedge"]["exittime"]).do(self.st.exitHedge)
        #schedule.every().day.at(self.deltaConfigDic["time"]['hedge']["chkStatus"]).do(self.fn.checkStatus)

