from kiteconnect import KiteConnect
import logging
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import pyotp, time
import time
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager
import sys



class login:

    def __init__(self, user):
        
        self.user = user
        userConfig = self.fn.read_file_json(f'common/config/users/{self.user}.json')

        self.api_key = userConfig['zerodha_api_key']
        self.api_secret = userConfig['zerodha_api_secret']
        self.userid = userConfig['zerodha_userid']
        self.userpwd = userConfig['zerodha_user_passwd']
        self.totp_key = userConfig['zerodha_totp_key']
        self.access_token = ""
        self.request_token = ""
        self.login_url = f'https://kite.trade/connect/login?api_key={self.api_key}&v=3'
        self.kite_conn = ""

    def getAccessToken(self):
        print('Access Token is old. Proceeding Login..')
        options = webdriver.FirefoxOptions()
        options.headless = True
        driver = webdriver.Firefox(service=Service(GeckoDriverManager().install()), options=options)
        print("gettin Access Token")
        driver.get(self.login_url)

        login_id = WebDriverWait(driver,10).until(lambda x: x.find_element(By.XPATH,'//*[@id="userid"]'))
        login_id.send_keys(self.userid)
        pwd = WebDriverWait(driver,10).until(lambda x: x.find_element(By.XPATH,'//*[@id="password"]'))
        pwd.send_keys(self.userpwd)

        submit = WebDriverWait(driver,10).until(lambda x: x.find_element(By.XPATH,'//*[@id="container"]/div/div/div[2]/form/div[4]/button'))
        submit.click()

        authkey = pyotp.TOTP(self.totp_key)
        #print(authkey.now())

        totp = WebDriverWait(driver,10).until(lambda x: x.find_element(By.XPATH,'//*[@id="totp"]'))
        totp.send_keys(authkey.now())

        submit2 = WebDriverWait(driver,10).until(lambda x: x.find_element(By.XPATH,'//*[@id="container"]/div/div/div/form/div[3]/button'))
        submit2.click()
        #print("Login Complete......")
        time.sleep(5)
        redirectUrl = driver.current_url
        #print("redirect url: ",  redirectUrl)

        self.request_token = redirectUrl.split('request_token=')[1].split('&')[0]

        #print(self.request_token)
        driver.close()
        self.kite_conn = KiteConnect(api_key = self.api_key)
        dataObj = self.kite_conn.generate_session(request_token=self.request_token,api_secret=self.api_secret)
        self.setAccessToken = self.kite_conn.set_access_token(dataObj['access_token'])
        self.accessToken = dataObj['access_token']
         
        return dataObj['access_token']