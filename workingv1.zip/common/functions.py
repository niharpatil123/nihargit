import json, sched, schedule, mibian, requests, pyotp, time
from datetime import datetime, timedelta, date
import pandas as pd
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager
from kiteconnect import KiteConnect, KiteTicker

class functions():

    def __init__(self, conn, tradeSymbol, positionSize, system, user):
        
        if tradeSymbol == "BANKNIFTY":
            self.symbolName = 'NSE:NIFTY BANK'
        else:
            self.symbolName = 'NSE:NIFTY 50'

        self.interestRate = 4
        self.tradeSymbol = tradeSymbol
        self.positionSize = positionSize
        self.system = system
        self.user = user
        self.KiteConn = conn
        self.quantity = self.getQuantity()
        # self.symbolSpot = self.getSpot()
    
        self.positionDict = {'hedge': {'callSymbol': 0, 'callStrike': 0, 'callPrice': 0, 'putSymbol': 0, 'putStrike': 0, 'putPrice': 0}, 'straddle': {'callSymbol': 0, 'callStrike': 0, 'callOrderId': 0, 'callPrice': 0, 'putSymbol': 0, 'putStrike': 0, 'putOrderId': 0, 'putPrice': 0}}

        f = open('common/config/config_telegram.json', "r")
        jsonconfig = f.read()
        f.close()
        telegramConfig = json.loads(jsonconfig)

        self.TELEGRAM_BOT_TOKEN = telegramConfig['bottoken']
        self.TELEGRAM_CHAT_ID = telegramConfig['chatid']
        self.TELEGRAM_ENABLE = telegramConfig['sendTelegramMsg']
        self.TELEGRAM_NOTIFY = telegramConfig['notify']


    def read_file_json(self, filename):        
        f = open(filename, "r")
        jsonconfig = f.read()
        f.close()
        jsonFile = json.loads(jsonconfig)
        return jsonFile

    def write_file_json(self, filename, jsonObject):        
        jsonObject = json.dumps(jsonObject)
        with open(f'common/orders/{filename}', "w") as outfile:
            outfile.write(jsonObject)

    def healthcheck(self, component):
    #Belows is healthcheck for Zerodha Kite API
        if component == 'zerodha':
            heathCheck_zerodha_login = requests.get('https://kite.trade')
            is_Zerodha_healthy =  heathCheck_zerodha_login.status_code
            if  is_Zerodha_healthy == 200:
                healthcheck_success_msg = 'Zerodha is accesible'
            else:
                healthcheck_success_msg = 'Zerodha is not reachable'
        print (healthcheck_success_msg)

    def nextExpiryDate(self):
        d = datetime.now()
        while d.weekday() != 3:
            d = d + timedelta(days=1)
            #print("Next Expiry Date: ",d)
      
        dayStr = str(d.strftime("%y")) + str(d.month) + str(d.day).zfill(2)
        nd = d + timedelta(days=1)
            
        while nd.weekday() != 3:
            nd = nd + timedelta(days=1)
            #print("Further Next Expiry Date: ", nd)

        if (nd.month != d.month):
            #print("Coming is Last Thursday of Month")
            dayStr = str(d.strftime("%y")) + (d.strftime("%b")).upper()
            #print("Further Next Expiry Date: ", dayStr)
        
        return dayStr

    def daysToExpiry(self):
        d = datetime.now()
        i = 0
        while d.weekday() != 3:
            d = d + timedelta(days=1)
            i = i+1
        # to manage last day of expiry. TO avoid divide by zero
        if (i == 0):
            i = 0.00001
        #print("Days to Expiry: ",i)
        return i



    def closest_value(self, input_list, input_value):
        difference = lambda input_list: abs(input_list - input_value)
        res = min(input_list, key=difference)
        return res

                
    def getHedgeStrike(self):
        #Decide the strike price
        self.symbolSpot = self.getSpot()
        if self.tradeSymbol  == "BANKNIFTY":
            self.hedgeStrike = round(self.symbolSpot/500)*500
        elif self.tradeSymbol  == "NIFTY":
            self.hedgeStrike = round(self.symbolSpot/50)*50

        print(f'Strike to calculate hedge for {self.tradeSymbol }:' , self.hedgeStrike)
        return self.hedgeStrike
    
    def getOptionsSymbols(self, ceStrike, peStrike):
        #Decide the strike price
        optionSymbols = {'opt': {'ceSymbol': 0, 'peSymbol': 0}}

        ceSymbol = f'NFO:{self.tradeSymbol }{self.nextExpiryDate()}{str(ceStrike)}CE'
        peSymbol = f'NFO:{self.tradeSymbol}{self.nextExpiryDate()}{str(peStrike)}PE'
        optionSymbols["opt"]["ceSymbol"] = ceSymbol
        optionSymbols["opt"]["peSymbol"] = peSymbol
        print (optionSymbols)
        return optionSymbols
    
    def getQuantity(self):
        #download the instruments from below and get the quantity for each lot
        #getInstruments = self.kiteConn.instruments()
        #print (getInstruments)
        if self.tradeSymbol == "BANKNIFTY":
            print ("Lot Size:", self.positionSize)
            totalLots = int(self.positionSize)
            qtyPerLot = int(25)
        elif self.tradeSymbol == "NIFTY":
            totalLots = int(self.positionSize)
            qtyPerLot = int(75)
            
        totalQty = int(qtyPerLot*totalLots);
        print (f'Total Quantity for {self.tradeSymbol} ::', totalQty)
        #self.sendTelegram(f'{self.tradeSymbol} >> Lot Size: {totalLots} :: Quantity: {totalQty}')
        return totalQty

    def getSpot(self):
        spotOhlc = self.KiteConn.ohlc(self.symbolName)
        print (spotOhlc)
        self.symbolSpot = spotOhlc[self.symbolName]['last_price']
        print(f'Spot for {self.tradeSymbol}: ',self.symbolSpot)
        return self.symbolSpot

    def getSL(self, price, leg):
        slValues = {'stopLoss': {'slPrice': 0, 'triggerPrice': 0}}
        threeLegConfig = self.read_file_json('systems/threeLeg/config_threeLeg.json')

        price = round(0.05 * round(price/0.05),2)

        weekday = datetime.today().strftime('%A')
        percentage = threeLegConfig["pct"][f'{leg}'][weekday]

        print (f'SL ** {weekday} :: {leg} :: {percentage} **')

        slLtp = price*(1+percentage/100)
        slTriggerPrice = round(0.05 * round(slLtp/0.05),2)
        slPrice = slTriggerPrice + 2
        print (f'Price {price} :: sl price {slPrice} :: TrigPrice {slPrice}')
        slValues["stopLoss"]["slPrice"] = slPrice
        slValues["stopLoss"]["triggerPrice"] = slPrice  
        return slValues

    def getAtmStrike(self):
        #Decide the strike price
        if self.tradeSymbol == 'BANKNIFTY':
            atmStrike = round(self.symbolSpot/100)*100
        elif self.tradeSymbol == 'NIFTY':
            atmStrike = round(self.symbolSpot/50)*50
        print(f'Selling Strike for {self.tradeSymbol}: ', atmStrike)
        return atmStrike

    def setActivePositions(self, positionDict):
        #This code writes active positions into JSON File on every trade order
        json_object = json.dumps(positionDict)
        print (json_object)
        with open(f'common/orders/{self.system}ActivePositions.json', "w") as outfile:
            outfile.write(json_object)

    def getActivePositions(self):
        #This code reads the positions from JSON File on every 5minutes
        file = open(f'common/orders/{self.system}ActivePositions.json',"r")
        positionList = json.load(file)
        print (positionList)
        return positionList
    
    def recordActivePostions(self, positionType, ceSymbol, peSymbol, ceStrike, peStrike, ceOrderId, peOrderId, callHedge, putHedge):
        ceEntryPrice = 0
        peEntryPrice = 0
        if positionType == 'hedge':
            self.positionDict["hedge"]["callSymbol"] = ceSymbol[4:]
            self.positionDict["hedge"]["putSymbol"] = peSymbol[4:]
            self.positionDict["hedge"]["callStrike"] = callHedge
            self.positionDict["hedge"]["putStrike"] = putHedge
            self.setActivePositions(self.positionDict)

        elif positionType == 'straddle':

            orderList = self.KiteConn.orders()
            for i in orderList:
                if(ceOrderId == i['order_id']):
                    ceEntryPrice = i['average_price']
                elif(peOrderId == i['order_id']):
                    peEntryPrice = i['average_price']
                
                #print ('pe entry price', peEntryPrice)
                print(i['order_id'],i['tradingsymbol'],i['transaction_type'],i['guid'],i['average_price'])
            
            #self.getActivePositions()
            self.positionDict["straddle"]["callSymbol"] = ceSymbol[4:]
            self.positionDict["straddle"]["putSymbol"] = peSymbol[4:]
            self.positionDict["straddle"]["callStrike"] = ceStrike
            self.positionDict["straddle"]["putStrike"] = peStrike
            self.positionDict["straddle"]["callOrderId"] = ceOrderId
            self.positionDict["straddle"]["putOrderId"] = peOrderId
            self.positionDict["straddle"]["callPrice"] = ceEntryPrice
            self.positionDict["straddle"]["putPrice"] = peEntryPrice
            #print (postionDict)
            self.setActivePositions(self.positionDict)

        return self.positionDict

    def checkPNL(self):
        margin = self.KiteConn.margins()
        realized = margin['equity']['utilised']['m2m_realised']
        unrealized = margin['equity']['utilised']['m2m_unrealised']
        total = realized + unrealized
        self.sendTelegram("Net Profit::: \\" + str(int(total)))

    def checkStatus(self):
        schedule.every(5).minutes.do(self.checkPNL)


    def getDeltaDataFrame(self, optionType):
        print("GenerateDataFrameFor:::", optionType)
        atmStrike = self.getAtmStrike()
        data = {
            "strikes": [atmStrike, atmStrike+100, atmStrike+200, atmStrike+300, atmStrike+400, atmStrike+500, atmStrike+600, atmStrike+700, atmStrike-100, atmStrike-200, atmStrike-300, atmStrike-400, atmStrike-500, atmStrike-600, atmStrike-700],
            "delta": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        }
        #load data into a DataFrame object:
        df = pd.DataFrame(data)
        #print(df)
        for index,row in df.iterrows():
            print("Strike: ", row['strikes'])
            strike = row['strikes']
            #self.getOptionsSymbols()
            position = "NFO:BANKNIFTY" + self.nextExpiryDate() + str(strike) + optionType
            if (optionType=="CE"):
                delta = self.getDelta(position, strike, 'call')
            elif (optionType=="PE"):
                delta = self.getDelta(position, strike, 'put')
            df.at[index, 'delta'] = abs(delta*1000)
        print(df)
        return df

    def getMatchingStrike(self, dataFrame, optionDelta):
        deltaList = dataFrame['delta']
        difference = lambda deltaList: abs(deltaList - optionDelta)
        nearestDelta = min(deltaList, key=difference)
        matchingStrike = dataFrame.loc[dataFrame['delta'] == nearestDelta, 'strikes'].iloc[0]
        return int(matchingStrike)
    
    def getDelta(self, optionSymbol, optionStrike, optionType):

        positionList = []
        positionList.append(optionSymbol)
        #print(positionList)
        #currPrices = conn.quote(positionList)
        #print(currPrices)
        ohlc = self.KiteConn.ohlc(optionSymbol)
        ltp = ohlc[optionSymbol]['last_price']

        #calcVol = mibian.BS([self.getSpot(), optionStrike, self.interestRate, self.ut.daysToExpiry()], optionType)
        calcVol = f'mibian.BS([{self.getSpot()}, {optionStrike}, {self.interestRate}, {self.daysToExpiry()}], {optionType}Price={ltp})'
        #print(calcVol)

        vol = eval(calcVol)

        implVol = float("{:2f}".format(vol.impliedVolatility))

        vdelta = mibian.BS([self.getSpot(), optionStrike, self.interestRate, self.daysToExpiry()], volatility=implVol)

        if optionType == 'call':
            delta = vdelta.callDelta
        else:
            delta = vdelta.putDelta

        return delta
    
    def isDeltaMisMatch(self):

        print(">> Intiated check for delta mismatch")
        startTime= datetime.now()
        timeNow = str(datetime.now().hour) + ":" + str(datetime.now().minute) + ":" + str(datetime.now().second)
        print("Time: ", timeNow)

        activePostionList = self.getActivePositions()
        ceSymbol = 'NFO:' + activePostionList["straddle"]["callSymbol"]
        peSymbol = 'NFO:' + activePostionList["straddle"]["putSymbol"]
        ceStrike = activePostionList["straddle"]["callStrike"]
        peStrike = activePostionList["straddle"]["putStrike"]

        ceDelta = self.getDelta(ceSymbol, ceStrike, 'call')
        peDelta = self.getDelta(peSymbol, peStrike, 'put')
        
        ceDeltaRound = ceDelta*1000
        peDeltaRound = peDelta*1000
        netDelta = ceDeltaRound + peDeltaRound
        print("Call Delta: ", ceDeltaRound, "Put Delta: ", peDeltaRound)
        print("Net Delta:", netDelta)

        self.sendTelegram("Net Delta:: \\" + str(int(netDelta)))
        #tm.telegram_sendmsg("Net Profit::: \\" + str(int(totalPNL)), "0")
        
        cePostionStatus = True
        pePositionStatus = True
        #ceDeltaRound = 200
        #peDeltaRound = 450
        if (abs(ceDeltaRound + peDeltaRound) > 200):
            print("There is a Delta Mismatch!")
            self.sendTelegram("Delta Mismatch :: ")
            if (abs(ceDeltaRound) > 700):
                print(" >> call delta more than 700. exiting call leg..", ceSymbol)
                self.exitOneLeg(ceSymbol[4:])
                cePostionStatus = False
                #self.sendTelegram("Exiting Call Leg", ceSymbol)
            elif (abs(peDeltaRound) > 700):
                print(">> put delta more than 700. exiting put leg..", peSymbol)
                self.exitOneLeg(peSymbol[4:])
                pePositionStatus = False
            elif (abs(ceDeltaRound) < 400):
                print(">> call delta less than 400. exiting call leg..", ceSymbol)
                self.exitOneLeg(ceSymbol[4:])
                cePostionStatus = False
            elif (abs(peDeltaRound) < 400):
                print(">> put delta less than 400. exiting put leg..", peSymbol)
                self.exitOneLeg(peSymbol[4:])
                pePositionStatus = False

            elif (abs(ceDeltaRound) > 450 and abs(ceDeltaRound) < 650):
                print(" >> call Delta between 450 & 650. exiting put leg", peSymbol)
                self.exitOneLeg(peSymbol[4:])
                pePositionStatus = False

            elif (abs(peDeltaRound) > 450 and abs(peDeltaRound) < 650):
                print(">> put Delta between 450 & 650. exiting call leg", ceSymbol)
                self.exitOneLeg(ceSymbol[4:])
                cePostionStatus = False

            elif (abs(ceDeltaRound) > 650 and abs(ceDeltaRound) < 700):
                # Condition for 650to 700...PENDING
                print(">> call Delta between 650 & 700. exiting call leg", ceSymbol)
                self.exitOneLeg(ceSymbol[4:])
                cePostionStatus = False

            elif (abs(peDeltaRound) > 650 and abs(peDeltaRound) < 700):
                # Condition for 650to 700...PENDING
                print(">> put Delta between 650 & 700. exiting put leg", peSymbol)
                self.exitOneLeg(peSymbol[4:])
                pePositionStatus = False

            #=================EXIT operations completed==========================#
            
            if (cePostionStatus == False and pePositionStatus == False):
                #enterFreshHedge(conn)
                self.sellStraddle()
            if (cePostionStatus == False and pePositionStatus == True):
                # find equivalent Call Option
                self.enterNewLeg("CE", abs(peDeltaRound))

            if (cePostionStatus == True and pePositionStatus == False):
                # find equivalent Put Option
                self.enterNewLeg("PE", abs(ceDeltaRound))

            endTime = datetime.now()
            print("Check Every 5 Minutes Completed::::", endTime-startTime)


    def buyHedge(self):
        print(">> Initiated buy order for hedge...")
        hedgeStrike = self.getHedgeStrike()

        if self.tradeSymbol == 'BANKNIFTY':
            ceHedge = hedgeStrike + 3000
            peHedge = hedgeStrike - 3000
        elif self.tradeSymbol == 'NIFTY':
            ceHedge = hedgeStrike + 1500
            peHedge = hedgeStrike - 1500      

        optSymbols = self.getOptionsSymbols(ceHedge, peHedge)
        ceSymbol = optSymbols["opt"]["ceSymbol"]
        peSymbol = optSymbols["opt"]["peSymbol"]

        print (optSymbols)

        self.placeOrder(ceSymbol[4:], 'buy', 'MIS', '', '', '', self.quantity)
        self.placeOrder(peSymbol[4:], 'buy', 'MIS', '', '', '', self.quantity)

        self.recordActivePostions('hedge', ceSymbol, peSymbol, '', '', '','',ceHedge, peHedge)
        self.sendTelegram('Hedge order placed::')
        self.sendTelegram(f'{self.tradeSymbol} :: CE :: {str(int(ceHedge))} :: PE ::{str(int(peHedge))}::')


    def sellStraddle(self):
        print(">> Initiated Sell Straddle...")

        self.getSpot()
        atmstrike = self.getAtmStrike()
        ceStrike = atmstrike
        peStrike = atmstrike

        optSymbols = self.getOptionsSymbols(atmstrike, atmstrike)
        ceSymbol = optSymbols["opt"]["ceSymbol"]
        peSymbol = optSymbols["opt"]["peSymbol"]

        #ceOrderId = self.placeOrder(ceSymbol[4:], 'sell', 'MIS', '', '', '', self.quantity)
        #peOrderId = self.placeOrder(peSymbol[4:], 'sell', 'MIS', '', '', '', self.quantity)

        ceOrderId = '220218201014337'
        peOrderId = '220218201014356'
        print ('ceorderid:', ceOrderId)
        print ('peorderid:', peOrderId)
        print(f'Staddle Placed >> {atmstrike}')
        self.recordActivePostions('straddle', ceSymbol, peSymbol, ceStrike, peStrike, ceOrderId, peOrderId, '', '')
        self.sendTelegram(f' ** {self.tradeSymbol} ** Straddle Placed ** {atmstrike} **' )
    
    def placeStopLoss(self, leg):
        print(">> Intiated Stop Loss Order...")
        ceTriggerPrice = 0
        peTriggerPrice = 0

        activePostionList = self.getActivePositions()

        ceSymbol = activePostionList["straddle"]["callSymbol"]
        peSymbol = activePostionList["straddle"]["putSymbol"]

        cePrice = activePostionList["straddle"]["callPrice"]
        pePrice = activePostionList["straddle"]["putPrice"]
  
        ceSLValues = self.getSL(cePrice, leg)
        peSLValues = self.getSL(pePrice, leg)

        ceSLPrice = ceSLValues["stopLoss"]["slPrice"]
        ceTriggerPrice = ceSLValues["stopLoss"]["triggerPrice"]
        peSLPrice = peSLValues["stopLoss"]["slPrice"]
        peTriggerPrice = peSLValues["stopLoss"]["triggerPrice"]

        #print (ceSLPrice, ceTriggerPrice, peSLPrice, peTriggerPrice)
        self.sendTelegram("Stop Loss Placed: CE SL :: " + str(int(ceSLPrice))  + ":: PE SL ::" + str(int(peSLPrice)))
        self.placeOrder(ceSymbol, 'buy', 'MIS', ceTriggerPrice, ceSLPrice, 'SL', self.quantity)
        self.placeOrder(peSymbol, 'buy', 'MIS', peTriggerPrice, peSLPrice, 'SL', self.quantity)

    def exitHedge(self):
        print(">> Initiating exit from Hedge orders..")
        positionList = self.KiteConn.positions()
        for i in positionList["day"]:
            if (i['quantity'] > 0 ):
                self.placeOrder(i["tradingsymbol"], 'sell', 'MIS', '', '', '', self.quantity)
        
        self.sendTelegram("Hedge Positions Exited\.\.")

    def exitStraddle(self):
        print(">> Initiating exit from straddle orders..")
        positionList = self.KiteConn.positions()
        for i in positionList["day"]:
            print(i["tradingsymbol"],"::::",i["quantity"])
            if(i["quantity"] < 0 ):
                self.placeOrder(i["tradingsymbol"], 'buy', 'MIS', '', '', '', self.quantity)
        
        self.sendTelegram("Straddle Positions Exited\.\.")

    def cancelSLOrders(self):
        print(">> Initiating cancel of all pending orders..")
        orderList = self.KiteConn.orders()
        for i in orderList:
            print(i["order_id"],"::::",i["status"])
            if(i["status"] == "TRIGGER PENDING" ):
                self.cancelOrder(i["order_id"], i["parent_order_id"])
                
    def cancelOrder(self, orderId, parentOrderId):
        conn = self.KiteConn
        order = conn.cancel_order(order_id=orderId, variety=conn.VARIETY_REGULAR, parent_order_id=parentOrderId)
        print("SL Order Successfully cancelled::::") 
        positionDict = {'hedge': {'callSymbol': 0, 'callStrike': 0, 'callPrice': 0, 'putSymbol': 0, 'putStrike': 0, 'putPrice': 0}, 'straddle': {'callSymbol': 0, 'callStrike': 0, 'callPrice': 0, 'putSymbol': 0, 'putStrike': 0, 'putPrice': 0}}

    def enterNewLeg(self, option, optionDelta):
        print("Enter New Leg: ", option, "##", optionDelta)
        positionDict = self.getActivePositions()

        dataFrame = self.getDeltaDataFrame(option)
        newStrike = self.getMatchingStrike(dataFrame, optionDelta)
        print("New Strike to enter:", newStrike)
        if option == "call":
            optionSymbols = self.getOptionsSymbols(newStrike,'')
            ceSymbol = optionSymbols["opt"]["ceSymbol"]
            positionDict["straddle"]["callSymbol"] = ceSymbol[4:]
            positionDict["straddle"]["callStrike"] = newStrike
            ceOrderID = self.placeOrder(ceSymbol[4:], 'sell', 'MIS', '', '', '', self.quantity)
            self.sendTelegram("New Leg Entered:: " + ceSymbol[4:] + " : " + str(int(newStrike)))
            self.recordActivePostions('straddle', ceSymbol, '', newStrike, '', ceOrderID, '', '', '')
        else:
            optionSymbols = self.getOptionsSymbols('', newStrike)
            peSymbol = optionSymbols["opt"]["peSymbol"]
            positionDict["straddle"]["putSymbol"] = peSymbol[4:]
            positionDict["straddle"]["Strike"] = newStrike
            peOrderID = self.placeOrder(peSymbol[4:], 'sell', 'MIS', '', '', '', self.quantity)
            self.sendTelegram("New Leg Entered:: " + peSymbol[4:] + " : " + str(int(newStrike)))
            self.recordActivePostions('straddle', '', peSymbol, '', newStrike, '', peOrderID, '', '')

    def placeOrder(self, tradeSymbol, orderType, productType, slPrice, triggerPrice, orderCategory, quantity):
        orderType = str.upper(orderType)
        productType = str.upper(productType)
        orderCategory = str.upper(orderCategory)
        conn = self.KiteConn
        if orderCategory == 'SL':
            orders = f'conn.place_order(tradingsymbol="{tradeSymbol}", quantity={quantity}, exchange=conn.EXCHANGE_NFO, order_type=conn.ORDER_TYPE_{orderCategory}, transaction_type=conn.TRANSACTION_TYPE_{orderType}, product=conn.PRODUCT_{productType}, variety=conn.VARIETY_REGULAR, trigger_price={triggerPrice}, price={slPrice})'
        else:
            orderCategory = 'MARKET'
            orders = f'conn.place_order(tradingsymbol="{tradeSymbol}", quantity={quantity}, exchange=conn.EXCHANGE_NFO, order_type=conn.ORDER_TYPE_{orderCategory}, transaction_type=conn.TRANSACTION_TYPE_{orderType}, product=conn.PRODUCT_{productType}, variety=conn.VARIETY_REGULAR)'

        print (orders)
        #od = eval(orders)
        print (f'** {tradeSymbol} ** {orderType} ** {quantity} ** {productType} ** ')
        #self.mg.sendTelegram(f'{orderType} Order Successfully Placed for:::: {self.tradeSymbol}')
        #return od

    def exitOneLeg(self, tradingsymbol):
        print("Exit One Leg: ", tradingsymbol)
        self.placeOrder(tradingsymbol, 'buy', 'MIS', '', '', '', self.quantity)


    def sendTelegram(self, msg):
        # notify:  0 means notify user and 1 means deliver the notification without notifying user\n",
        msg = str(msg)
        send_msg = 'https://api.telegram.org/bot' + self.TELEGRAM_BOT_TOKEN + '/sendMessage?chat_id=' + self.TELEGRAM_CHAT_ID + '&parse_mode=MarkdownV2&disable_notification=' + self.TELEGRAM_NOTIFY + '&text=' + '\\' + msg
        
        if self.TELEGRAM_ENABLE == 'On':
            response = requests.get(send_msg, verify=False)
            print(response.text)
        else:
            #print('Telegram message is set to Off. To send msg toggle it to On')
            print('.')

#logging.basicConfig(level=logging.DEBUG)

